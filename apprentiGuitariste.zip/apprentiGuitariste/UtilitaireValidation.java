
import java.util.Scanner;

public class UtilitaireValidation {
	
	 // Sert � retenir si l'utilisateur a annul�.
		private static boolean utilisateurAnnule = false;
		
		// Pour la lecture au clavier.
		private static Scanner clavier= new Scanner(System.in);
		
		
		
		/*******************************
		 * LIRE INT
		 *******************************/
		/**
		 * Affiche le message re�u et attend l'entr�e d'un
		 * nombre entier entre les deux bornes (min et max).
		 * L'utilisateur annule s'il fait seulement "entr�e"
		 * Si l'utilisateur annule, la fonction retourne 0
		 * et la fonction utilisateurAnnule() retournera true.
		 * 
		 * @param msg Le message de sollicitation
		 * @param min limite inf�rieure accept�e
		 * @param max limite sup�rieure accept�e
		 * @return un entier entre min et max
		 */
		public static int lireInt(String msg,int min, int max){
					
			// Sert � la saisir.
			String valeurLue = null;
			
			// Sera mis � true lorsque valide.
			boolean valide = false;
			
			// Sert � valider le nombre.
			int valInt = 0;
					
			// Attribut gobal mis � faux.
			utilisateurAnnule = false;
					
			while(!valide && !utilisateurAnnule){			
			    
			        // Sollicitation de l'utilisateur pour la valeur.
				    System.out.print(msg + " (<entr�e> pour annuler) : ");
				    
			        // On lit toute la ligne.		        
				    valeurLue = clavier.nextLine();
				    
				    // Si l'utilisateur annule, c'est valide quand m�me.
				    if (valeurLue.equals("")){
				    	
				    	utilisateurAnnule = true; 
				    }//if
				    		    
				    // Sinon on tente de convertir en entier.
				    else
				    {
			
						try{
							// Si on r�ussit la conversion sans exception.
							valInt = Integer.parseInt(valeurLue);
							
							// On �value les bornes.
							if(valInt < min || valInt > max)
							     System.out.println("la valeur entr�e doit �tre " +
							     		            "entre "+min + " et" + max);						

					        // Si on vient ici c'est que tout est beau.
					        else
								valide = true;
						}//try
						
					    // S'il y a une exception lors de la conversion 
					    // on avise et valide reste faux.
						catch (Exception e){
						     System.out.println("la valeur entr�e doit �tre " +
				     		            "entre "+min + " et" + max);
						}//catch
				    }// else
			}//while
			
			return valInt;
		}
		

		/*******************************
		 * LIRE DOUBLE
		 *******************************/
		/**
		 * Affiche le message re�u et attend l'entr�e d'un
		 * nombre r�el entre les deux bornes (min et max).
		 * Si l'utilisateur annule, la fonction retourne 0
		 * et la fonction utilisateurAnnule() retournera true.
		 * 
		 * @param msg Le message de sollicitation
		 * @param min limite inf�rieure accept�e
		 * @param max limite sup�rieure accept�e
		 * @return un r�el entre min et max
		 */
		public static double lireDouble(String msg,double min, double max){
					
			// Sert � la saisir.
			String valeurLue = null;

			// Sera mis � true lorsque valide.
			boolean valide = false;

			// Sert � valider le nombre.
			double valDouble = 0;


			// Attribut gobal mis � faux.
			utilisateurAnnule = false;
							
			while(!valide && !utilisateurAnnule){			

			        // Sollicitation de l'utilisateur pour la valeur.
				    System.out.print(msg + " (<entr�e> pour annuler) : ");
				    
			        // On lit toute la ligne.		        
				    valeurLue = clavier.nextLine();
				    
				    // Si l'utilisateur annule, c'est valide.
				    if (valeurLue.equals("")){
				    	utilisateurAnnule = true; 
				    }
				    		    
				    //S inon on tente de convertir en r�el.
				    else 
			
						try{
							// Si on r�ussit la conversion sans exception.
							valDouble = Double.parseDouble(valeurLue);
							
							// On �value les bornes.
							if(valDouble < min || valDouble > max)
							     System.out.println("la valeur entr�e doit �tre " +
							     		            "entre "+min + " et" + max);
							
					        // Si on vient ici c'est que tout est beau.
					        else
								valide = true;
						}//try
						
					    // S'il y a une exception lors de la conversion 
					    // on avise et valide reste faux.
						catch (Exception e){
						     System.out.println("la valeur entr�e doit �tre " +
				     		            "entre "+min + " et" + max);
						}//catch
			}//while
			
			return valDouble;
		}

		/*******************************
		 * LIRE STRING
		 *******************************/
		/**
		 * Affiche le message re�u et attend l'entr�e d'une
		 * cha�ne.  L'utilisateur annule en entrant une cha�ne vide.
		 * Si l'utilisateur annule, la fonction retourne null
		 * et la fonction utilisateurAnnule() retournera true.
		 * 
		 * @param msg Le message de sollicitation.
		 * @return la cha�ne saisie.
		 */
		public static String lireString(String msg){
					
			// Sert � la saisir.
			String valeurLue = null;

			// Attribut gobal mis � faux.
			utilisateurAnnule = false;
			
	        // Sollicitation de l'utilisateur pour la cha�ne.
		    System.out.print(msg + " (<entr�e> pour annuler) : ");
				    
	        // On lit toute la ligne.		        
		    valeurLue = clavier.nextLine();
	    		    
			// Si l'utilisateur annule, c'est valide
			// et on retourne null.
			if (valeurLue.equals("")){
				
			  	utilisateurAnnule = true;
			  	valeurLue = null;
			}
		    	
			return valeurLue;		
	    }
		

		/*******************************
		 * UTILISATEUR ANNULE
		 *******************************/
		/**
		 * Retourne si l'utilisateur a annul� lors de la derni�re lecture au clavier.
		 * Cet attribut est remis � faux apr�s consultation.
		 * 
		 * @return Si l'utilisateur a annul� lors de sa derni�re action.
		 */
		public static boolean utilisateurAnnule() {
			
			return utilisateurAnnule;
		}

		/**
		 * R�initialise la derni�re annulation de l'utilisateur.  On ne consid�re
		 * plus qu'il a annul�1
		 * 
		 */
		public static void reinitialise() {
			
			utilisateurAnnule = false;
		}
		/*******************************
		 * PAUSE
		 *******************************/
		/**
		 * Permet de demander a l'utilisateur d'appuyer sur une touche pour 
		 * continuer et d'attendre l'entr�e de l'utilisateur.
		 */
		public static void pause(){
			
			final int NB_CAR = 100;
			
			try{

				System.out.print("Appuyez sur une touche pour continuer...");
				System.in.read();
				
				// Vide le tampon des caract�res potentiellement entr�s.
				System.in.skip(NB_CAR);
			}
			
			catch(Exception e){
				e.printStackTrace();
			}
		}		

}
